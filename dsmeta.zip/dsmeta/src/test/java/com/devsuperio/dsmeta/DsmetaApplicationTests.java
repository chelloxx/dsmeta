package com.devsuperio.dsmeta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DsmetaApplicationTests {

	@Test
	void contextLoads() {
	}

}
